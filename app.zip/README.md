This is a project for MDM pyhton refresh course.

This simple application provides a To-do-list for the user.

The main functions are:
-GET 
-POST
-DELETE
The tasks that the user inputs into the To-do-list are then prcocessed to show information about the entry.

For example a new taks like:
"run test in localhost"

Will produce this additional info:

<img width="311" alt="Screenshot 2025-03-17 at 12 15 30" src="https://github.com/user-attachments/assets/d5eb1774-178c-4ebe-8927-129d44880765" />
